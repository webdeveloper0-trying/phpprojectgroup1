<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="style1.css">
</head>

<body class="left">
    <h1><u>Make Appointment</u></h1>
    <h4 class="mt-3 text-center
      Maketext">Make an appointment with the doctor right now and choose your preferred date and time!!!</h4>
    <div class="conatiner mt-5 ">
        <div class="row">
            <div class="col-5 ms-5 bg-white">
                <div>
                    <div class="needtext">
                        <h6>Need a appointment??</h6>
                    </div>

                    <div class="gcolor">
                        <p>This Appointment is ONE WEEK BOOKING.So,you must take a booking BEFORE ONE WEEK the day you come our hospital</p>
                    </div>
                    <div class="tagging">

                        <p> Select Speciality you want to take a booking</p>
                        <p>Select Doctor from the following of the </p>
                        <p>Click The Appointment Button</p>
                        <p>Fill infos in the Appointment form and Click Send</p>
                        <p>Appointment Code and QR code will be appeared</p>
                    </div>
                </div>
            </div>

            <div class="col-6 ">

                <select class="form-select form-select-sm select" aria-label=".form-select-sm example">
                    <option selected>Select Speciality</option>
                    <option value="1">Eye</option>
                    <option value="2">Skin</option>
                    <option value="3">Nerves</option>
                </select>
                <div class="pupple">Doctor list</div>
                <div class="board">
                    <div class="row">
                        <div class="col-3 mt-5">
                            <a href="" class="a">Dr.Hnin Ye Lwin</a>
                            <a href="" class="a">Dr.Lwin Mar Oo</a>
                            <a href="" class="a">Dr.KHIN Mya Aye</a>
                            <a href="" class="a">Dr.CHO Mar Lwin</a>
                            <a href="" class="a">Dr.MYA Aye</a>
                        </div>
                        <div class="col-3 mt-5">
                            <button type="button" class="btn btn-danger ">Aung Aung</button>
                            <button type="button" class="btn btn-warning mt-3">Khin Mya</button>
                            <button type="button" class="btn btn-info mt-3 mb-3">Thet Thet</button>
                        </div>
                        <div class="col-3 mt-5">
                            <button type="button" class="btn btn-light">Yoon Yoon</button>
                            <button type="button" class="btn btn-dark mt-3">Phyu thwe khin</button>
                            <button type="button" class="btn btn-link mt-3 mb-3">Linn</button>
                        </div>
                    </div>
                </div>
            </div>




            <!-- container div end -->
        </div>


</body>

</html>