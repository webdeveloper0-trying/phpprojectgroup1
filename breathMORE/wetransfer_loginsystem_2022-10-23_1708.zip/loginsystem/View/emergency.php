<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="./emergency.css">
</head>

<body>
    <div class="container-fluid">
        <h3><u>Emergency Departments & Ambulance Services</u></h3>
        <div class="row">
            <div class="col-7">
                <h6>In Case of Emergecy,Please Call
                    09455 222 111</h6>
                <p>Whether you arrive because of broken bones or a heart attack, our certified and specially trained physicians and nurses are committed to providing you with the highest level of emergency care in a safe environment. </p>
            </div>
            <div class="col-5">
                <img src="./Rectangle 21.jpg" alt="">
            </div>
        </div>
        <!-- sencond part -->
        <div class="row">
            <div class="col-5">
                <img src="./emergency.2.jpg" alt="" srcset="">
            </div>
            <div class="col-7">
                <h5>Emergency ambulance service for both local & remote area</h5>
                <p>*Hospital to Hospital patient transfer, Airport and Seaport pickup service<br>
                    *Ambulance for out-patient appointments, admission and discharge
                    Home visit<br>
                    *Ambulance and medical cover for sports activities, events, festivals, conference
                </p>
            </div>
        </div>
        <!-- third part -->
        <div class="row">
            <div class="col-8">
                <h2>24/7 Oxygen Available Places In Yangon</h2>
                <span class="badge bg-primary">Primary</span>
                <span class="badge bg-secondary">Secondary</span>
                <span class="badge bg-success">Success</span>
            </div>
            <div class="col-4">
                <img src="./o2.png" alt="" srcset="">
            </div>
        </div>
        <!-- fourth part -->
        <div class="row">
            <div class="col-3">
                <img src="./24hr.jpg" alt="" srcset="">
            </div>
            <div class="col-6">
                <h2>24 hours Call Centers</h2>
                <p>Billing & Payment Services
                    <br>
                    01-231 777, 01-523 444
                </p>
                <p>Admission Information
                    <br>
                    01-222 1111, 01-444 000
                </p>
                <p>Outpatient Appointments
                    <br>
                    01-666 888, 01-567 999, 09-422049911
                </p>
            </div>
        </div>
        <!-- feedback -->

        <h1>FeedBack Corner</h1>
        <label for="">Types of service
            <div class="input-group mb-3">
                <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default">
            </div>
        </label>

        <div class="row">
            <div class="col-9">
                <div class="input-group mb-3">
                    <label for=""> Any Sugesstion for our services
                        <input type="text" class="form-control" placeholder="Recipient's username" aria-label="Recipient's username" aria-describedby="button-addon2">
                    </label>
                </div>
            </div>

            <div class="col">
                <button type="sumit" class="btn btn-primary">Sumit</button>
            </div>
        </div>

    </div>
</body>

</html>