$("#eye").click(function (event) {
  let center = event.target.innerText;
  let center1 = {
    centerName: center,
  };
  $.ajax({
    url: "../Controller/centerController.php",
    type: "POST",
    data: center1,
    success: function (res) {
      console.log(res);
      let centerresult = JSON.parse(res);
      console.log(centerresult);
      // let diseases = JSON.parse(res);
      // console.log(diseases);
      $("#doctorlist").empty();
      let count = 1;
      for (const doctorlist of centerresult) {
        $("#doctorlist").append(`
        <p>(${count++})${doctorlist.doctor_name}</p>`);
      }
    },
    error: function (err) {
      alert("err");
    },
  });
});
$("#panelsStayOpen-headingTwo").click(function (event) {
  let center = event.target.innerText;
  let center1 = {
    centerName: center,
  };
  $.ajax({
    url: "../Controller/centerController.php",
    type: "POST",
    data: center1,
    success: function (res) {
      console.log(res);
      let centerresult = JSON.parse(res);
      console.log(centerresult);
      // let diseases = JSON.parse(res);
      // console.log(diseases);
      $("#general").empty();
      let count = 1;
      for (const doctorlist of centerresult) {
        $("#general").append(`
        <p>(${count++})${doctorlist.doctor_name}</p>`);
      }
    },
    error: function (err) {
      alert("err");
    },
  });
});
$("#panelsStayOpen-headingThree").click(function (event) {
  center = event.target.innerText;
  let center1 = {
    centerName: center,
  };
  $.ajax({
    url: "../Controller/centerController.php",
    type: "POST",
    data: center1,
    success: function (res) {
      console.log(res);
      let centerresult = JSON.parse(res);
      console.log(centerresult);
      // let diseases = JSON.parse(res);
      // console.log(diseases);
      $("#skin").empty();
      let count = 1;
      for (const doctorlist of centerresult) {
        $("#skin").append(`<p>(${count++})${doctorlist.doctor_name}</p>`);
      }
    },
    error: function (err) {
      alert("err");
    },
  });
});
$("#panelsStayOpen-headingFour").click(function (event) {
  let center = event.target.innerText;
  let center1 = {
    centerName: center,
  };
  $.ajax({
    url: "../Controller/centerController.php",
    type: "POST",
    data: center1,
    success: function (res) {
      console.log(res);
      let centerresult = JSON.parse(res);
      console.log(centerresult);
      // let diseases = JSON.parse(res);
      // console.log(diseases);
      $("#surgery").empty();
      let count = 1;
      for (const doctorlist of centerresult) {
        $("#surgery").append(`
        <p>(${count++})${doctorlist.doctor_name}</p>`);
      }
    },
    error: function (err) {
      alert("err");
    },
  });
});
$("#panelsStayOpen-headingFive").click(function (event) {
  let center = event.target.innerText;
  let center1 = {
    centerName: center,
  };
  $.ajax({
    url: "../Controller/centerController.php",
    type: "POST",
    data: center1,
    success: function (res) {
      console.log(res);
      let centerresult = JSON.parse(res);
      console.log(centerresult);
      // let diseases = JSON.parse(res);
      // console.log(diseases);
      $("#og").empty();
      let count = 1;
      for (const doctorlist of centerresult) {
        $("#og").append(`
        <p>(${count++})${doctorlist.doctor_name}</p>`);
      }
    },
    error: function (err) {
      alert("err");
    },
  });
});

$("#panelsStayOpen-headingSix").click(function (event) {
  let center = event.target.innerText;
  console.log(center);
  let center1 = {
    centerName: center,
  };
  $.ajax({
    url: "../Controller/centerController.php",
    type: "POST",
    data: center1,
    success: function (res) {
      console.log(res);
      let centerresult = JSON.parse(res);
      console.log(centerresult);
      // let diseases = JSON.parse(res);
      // console.log(diseases);
      $("#child").empty();
      let count = 1;
      for (const doctorlist of centerresult) {
        $("#child").append(`
        <p>(${count++})${doctorlist.doctor_name}</p>`);
      }
    },
    error: function (err) {
      alert("err");
    },
  });
});
$("#panelsStayOpen-headingSeven").click(function (event) {
  let center = event.target.innerText;
  let center1 = {
    centerName: center,
  };
  $.ajax({
    url: "../Controller/centerController.php",
    type: "POST",
    data: center1,
    success: function (res) {
      console.log(res);
      let centerresult = JSON.parse(res);
      console.log(centerresult);
      // let diseases = JSON.parse(res);
      // console.log(diseases);
      $("#kidney").empty();
      let count = 1;
      for (const doctorlist of centerresult) {
        $("#kidney").append(`
        <p>(${count++})${doctorlist.doctor_name}</p>`);
      }
    },
    error: function (err) {
      alert("err");
    },
  });
});
$("#panelsStayOpen-headingEight").click(function (event) {
  let center = event.target.innerText;
  let center1 = {
    centerName: center,
  };
  $.ajax({
    url: "../Controller/centerController.php",
    type: "POST",
    data: center1,
    success: function (res) {
      console.log(res);
      let centerresult = JSON.parse(res);
      console.log(centerresult);
      // let diseases = JSON.parse(res);
      // console.log(diseases);
      $("#heart").empty();
      let count = 1;
      for (const doctorlist of centerresult) {
        $("#heart").append(`
      <p>(${count++})${doctorlist.doctor_name}</p>`);
      }
    },
    error: function (err) {
      alert("err");
    },
  });
});

// let center1 = {
//   centerName: center,
// };
// $.ajax({
//   url: "../Controller/centerController.php",
//   type: "POST",
//   data: center1,
//   success: function (res) {
//     console.log(res);
//     let center = JSON.parse(res);
//     $("#centerlist").empty();
//     for (const centers of diseases) {
//       $("#centerlist").append(`
//     <p>${drug.disease_names}------>${drug.medicine_names}</p>`);
//     }
//   },
//   error: function (err) {
//     alert("err");
//   },
// });
