<?php
session_start();

include "../Model/dbConnect.php";

$name = $_SESSION["username"];
$sql = $pdo->prepare("SELECT * FROM total_registered_accounts WHERE  user_name=:username");
$sql->bindValue(":username", $name);
$sql->execute();

$patientinfo = $sql->fetchAll(PDO::FETCH_ASSOC);
$_SESSION["patientinfo"] = $patientinfo;
header("location: ../View/userprofile.php");
