<?php
include "../Model/dbConnect.php";
if (isset($_POST["profile"])) {
    // get patient info
    $gender = $_POST["Gender"];
    $age = $_POST["Age"];
    $dateofbirth = $_POST["date of birth"];
    $id = $_POST["id"];

    // get img
    if ($_FILES["upload"]['name'] == "") {
        $sql = $pdo->prepare(
            "UPDATE total_registered_accounts SET
            age=:age ,gender=:gender,date_of_birth=:dateofbirth WHERE register_id=:id"
        );
    } else {
        $file = $_FILES["upload"]["name"];
        $location = $_FILES["upload"]['tmp_name'];
        $extension = pathinfo($file)['extension'];
        $path = $id . "." . $extension;

        if (move_uploaded_file($location, "../storage/" . $id . "." . $extension)) {
            $sql = $pdo->prepare(
                "UPDATE total_registered_accounts SET
                age=:age ,gender=:gender,date_of_birth=:dateofbirth ,
                profile =:profile
                WHERE register_id=:id"
            );

            $sql->bindValue(":profile", $path);
        } else {
            echo "sorry";
        }
    }
    $sql->bindValue(":age", $age);
    $sql->bindValue(":gender", $gender);
    $sql->bindValue(":dateofbirth", $dateofbirth);
    $sql->bindValue(":id", $id);
    $sql->execute();
    header("location:../View/home.php");
}
