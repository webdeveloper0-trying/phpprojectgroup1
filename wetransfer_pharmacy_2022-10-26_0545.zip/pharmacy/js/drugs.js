$("#search").click(function () {
  if ($("#searchtext").val() == "") {
    alert("ok");
  } else {
    let sendData = {
      searchtext: $("#searchtext").val(),
    };
    $.ajax({
      url: "../Controller/drugsController.php",
      type: "POST",
      data: sendData,
      success: function (res) {
        console.log(res);
        let diseases = JSON.parse(res);
        $("#searchResult").empty();
        for (const drug of diseases) {
          $("#searchResult").append(`
          <p>${drug.disease_names}------>${drug.medicine_names}</p>`);
        }
      },
      error: function (err) {
        alert("err");
      },
    });
  }
});
// pharmacy
$("#state").change(function () {
  var selectedSubject = $("#state option:selected").val();
  // alert("You have selected the country " + selectedSubject);

  if (selectedSubject == 0) {
    alert("Pleased Choose Your township!!");
  } else {
    console.log(selectedSubject);
    let sendData = {
      searchtownship: selectedSubject,
    };
    $.ajax({
      url: "../Controller/pharmacyController.php",
      type: "POST",
      data: sendData,
      success: function (res) {
        console.log(res);
        let township = JSON.parse(res);
        $("#pharmacy").empty();
        for (const town of township) {
          $("#pharmacy").append(`
            <div class="card ms-3 mt-3 mb-3 h-100 "
            " style=" width: 15rem;">
            <img src="./${town.pharmacy_photo}" class="card-img-top" alt="..." width="200">
            <div class="card-body ">
                <h5 class="card-title">${town.pharmacy_name}</h5>
                <p>${town.pharmacy_address}</p>
                <p>${town.ph_num}</p>
                <p>${town.township}</p>
            </div>
  
           `);
        }
      },
      error: function (err) {
        alert("err");
      },
    });
  }
});
