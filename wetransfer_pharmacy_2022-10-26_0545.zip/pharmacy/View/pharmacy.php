<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="./pharmacy.css">
    <script src="../js/jquery3.6.0.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.22/pdfmake.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/0.4.1/html2canvas.min.js"></script>
    <link rel="stylesheet" href="./pharmacy.css">
    <script src="../js/drugs.js" defer></script>
</head>

<body class="pharmacybg">
    <div class="display-4"><u>Pharmacies Near Me</u></div>
    <div class="state">
        <h6>State & Regins</h6>
    </div>
    <div class="container">
        <class class="row">
            <div class="col-6 col-sm-5 col-md-6">
                <div class="row">
                    <!-- selectstart -->
                    <div class="state col-6">
                        <select class="form-select state" id="state" aria-label="Default select example">
                            <option>Township</option>
                            <option value="Mingaladon">Mingaladon</option>
                            <option value="Insein">Insein</option>
                            <option value="Hlaingthayar">Hlaingthayar</option>
                            <option value="Thanlyin">Thanlyin</option>
                            <option value="Latha">Latha</option>
                            <option value="Lanmadaw">Lanmadaw</option>
                            <option value="Pabedan">Pabedan</option>
                            <option value="Dagon">Dagon</option>
                            <option value="Ahlon">Ahlon</option>
                            <option value="Kyeemyintdaing">Kyeemyintdaing</option>
                            <option value="SanChaung">SanChaun</option>
                            <option value="South Okkalapa">South Okkalapa</option>
                        </select>
                    </div>
                </div>
            </div>
            <!-- pharmacyleftend -->
            <!-- drugs -->
            <div class="col-6 col-sm-5 offset-sm-2 col-md-6 offset-md-0">
                <div class="row" mt-5>
                    <div class="col-6">
                        <input type="text" id="searchtext" class="form-control" placeholder="drugs deal with diseases">
                    </div>
                    <div class="col-3">
                        <button class="btn btn-primary" id="search">Search</button>
                    </div>
                    <div class="drug" id="searchResult"></div>
                </div>
                <!-- end drugs -->
                <div class="pharmacy mt-5">

                    <!-- end pharmacy1 -->
                    <div class="holebody col-sm-5 offset-sm-2 d-inline-flex  " style="background-color:#8a39ab; width:auto" id="pharmacy">




                        <!--End holebody  -->
                    </div>

                </div>
            </div>
    </div>
    </div>
</body>

</html>