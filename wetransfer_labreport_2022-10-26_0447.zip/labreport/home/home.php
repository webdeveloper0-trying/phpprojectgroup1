<a href="../View/labreport.php">Lab report</a>

<!-- home nav bar -->